## Summary
Describe what this PR does and why. Link to any related issue/story.

## Screenshots / GIFs
- [ ] Light mode
- [ ] Dark mode

## What changed?
- [ ] UI/UX only
- [ ] Calculation logic
- [ ] Data (`data/rates.json`)
- [ ] Build/Deploy/Docs

## Checklist
- [ ] i18n keys added for all new texts (`data-i18n`)
- [ ] Tested on mobile and desktop
- [ ] Light/Dark theme verified (contrast OK)
- [ ] Category width remains fixed (no layout shifts)
- [ ] Charts updated without console errors
- [ ] Report (PDF) renders and paginates when long
- [ ] `rates.json` schema unchanged (if changed, document migration)
- [ ] CHANGELOG updated

## How to test
1. Open the page, select a category → VAT/TAX should auto-fill.
2. Run **Calculate**; verify 5 cards and both charts update.
3. Save → History should list with timestamp; Export CSV & Share work.
4. Generate **Report** and **PDF**; check values & formatting.

## Risk / Rollback plan
- If something breaks, revert to previous tag and clear Pages cache by hard refresh.
