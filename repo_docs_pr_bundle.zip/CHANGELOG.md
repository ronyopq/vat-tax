# Changelog
All notable changes to this project will be documented in this file.

## [v5.0.0] - 2026-03-03
### Added
- Corporate dashboard layout with sidebar history and top toolbar.
- Five redesigned **result cards** with consistent headers & tables.
- **Mini charts** (Chart.js): Composition (donut) & view comparison (bar).
- **History**: Save/Reapply + **Export CSV** + **Share link**.
- **Auto-save** last used category (localStorage) + read from query params.
- **Custom report** (jsPDF + AutoTable) with five sections.
- **Category width locked** (320px) with ellipsis.

### Changed
- View‑1 & View‑2 redesigned to match View‑3/4/5 layout style.

### Fixed
- Category auto‑fill reliability with/without Choices; default selection before init.

### Notes
- Keep `data/rates.json` at `repo-root/data/rates.json`.
- Hard refresh after deployment to bypass CDN/browser cache.
