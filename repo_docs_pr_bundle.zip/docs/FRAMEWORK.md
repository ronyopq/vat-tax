# BD VAT & TAX — Corporate Dashboard

> **Framework Guideline / Engineering Playbook**  
> Version: **v5.0.0**  ·  Updated: **2026-03-03**

This document standardizes architecture, UX patterns, calculation rules (Excel‑aligned), and release/deploy workflows for the BD VAT & TAX Calculator web app.

---

## 0) Goals & Non‑Goals

**Goals**
- Bangladesh VAT/TAX calculation across **5 result views** following Excel logic.
- **BN/EN bilingual**, **Light/Dark theme**, corporate‑grade UI.
- **Category → auto VAT/TAX** with override in Custom mode.
- **History** (save/reapply/export/share) + **Reportable PDF**.
- Static app (no backend) deployable on **GitHub Pages**.

**Non‑Goals**
- Server/DB, automated legal updates of rates (manually maintained in `data/rates.json`).

---

## 1) Tech Stack
- HTML/CSS/Vanilla JS (no build tool required).
- **Choices.js** (searchable select), **Chart.js** (donut/bar), **html2canvas + jsPDF + AutoTable** (PDF), **localStorage** for persistence.
- Hosting: **GitHub Pages**.

---

## 2) Project Structure
```
repo-root/
│── index.html
│── styles.css
│── app.js
│── CHANGELOG.md
│── README.md
├─ .github/
│   └─ pull_request_template.md
└─ docs/
    └─ FRAMEWORK.md  ← (this file)
└─ data/
    └─ rates.json
```
> `data/rates.json` must live under **/data** at repo root (app fetches `data/rates.json`).

---

## 3) Data Model

### `data/rates.json`
```jsonc
[
  {
    "item_bn": "যানবাহন (গাড়ি)",
    "item_en": "Vehicle (Car)",
    "vat_rate": 15,
    "tax_rate": 5
  }
]
```

### UI State (in-memory)
```js
{
  lang: 'bn'|'en', theme: 'light'|'dark',
  category: { item_bn, item_en, vat_rate, tax_rate } | null,
  rateSource: 'fromList'|'custom', vat: number, tax: number,
  amount: number, currency: string
}
```

### Persistence (localStorage)
- `lang`, `theme`, `last_category`, `vat_tax_history: [{item,amount,v,t,ts}]`

---

## 4) Calculation Engine (Excel‑aligned)
**Inputs:** Bill amount, VAT% (=v), TAX% (=t); `V=v/100`, `T=t/100`.

**View‑1: Gross UP (Base → Total)**
- Base = `bill`  
- VAT = `Base×V`  
- TAX = `Base×T`  
- **Total = Base + VAT + TAX**

**View‑2: Procurement/Vendor**
- Base = `bill`; VAT = `Base×V`; TAX = `Base×T`  
- **Total Amount = Base + VAT**; **Actual Pay = Base − TAX**

**View‑3: Including VAT & TAX (bill includes VAT)**
- Base = `Bill/(1+V)`; VAT(comp) = `Bill−Base`; TAX = `Base×T`  
- **Net = Bill − VAT − TAX**

**View‑4: Excluding VAT & TAX (bill excludes both)**
- AddTAX = `Base×T`; AddVAT = `Base×V`; Total = `Base+AddTAX+AddVAT`  
- LessVAT = AddVAT; LessTAX = AddTAX; **Net = Base**

**View‑5: Excluding VAT (bill excludes only VAT)**
- AddVAT = `Base×V`; Total = `Base+AddVAT`  
- LessVAT = AddVAT; LessTAX = `Base×T`; **Net = Base − TAX**

**Precision:** 2 decimals in UI/report (configurable).

---

## 5) UI/UX Standards
- **Sidebar**: brand, language/theme, history (save/reapply/export/share/clear).
- **Toolbar**: category (Choices), rate source, VAT/TAX, amount, currency, actions (Calculate/Save/PDF/Report).
- **Mini‑charts**: composition donut (Base/VAT/TAX) + bar (v1..v5 key metrics).
- **Results grid**: 5 **cards** share identical structure (header badges + table rows). Color accents differentiate.
- **Category width lock**: fixed at 320px; long labels ellipsized.
- **Theming**: `:root[data-theme]` tokens; maintain contrast ≥ 4.5:1.
- **i18n**: `data-i18n` keys; `_i18n.bn/en` dictionary; `localStorage.lang`.
- **Accessibility**: focus outlines, large hit areas (≥44px), labels/aria.

---

## 6) Events & State Flow
1) **Init**: fetch `rates.json` (cache: no-store) → set last_category → apply query `?a=&v=&t=` → first calc + charts.
2) **Category change**: parse JSON option (Choices/native) → auto‑fill VAT/TAX (from list) unless Custom → set `last_category` → recalc.
3) **Calculate**: compute 5 views → refresh cards + charts.
4) **Save**: push to `vat_tax_history` (cap 200) → re-render history.
5) **Export/Share**: CSV download; Web Share or clipboard link with query params.
6) **Report/PDF**: jsPDF‑AutoTable tabular; html2canvas screenshot PDF.

---

## 7) Charts (Chart.js)
- **Donut** labels: Base/VAT/TAX; dataset from View‑1: `[base, vat, tax]`; cutout 55%; legend: bottom.
- **Bar** labels: `['GrossUp Total','Actual Pay','Incl.Net','Excl.Net','Excl VAT Net']`; dataset numeric array; y beginAtZero.

---

## 8) Error Handling & Fallbacks
- Missing `rates.json` → show empty list + hint; allow Custom mode.
- Choices.js CDN failure → native `<select>` continues to work.
- PDF libs absent → disable Report/PDF buttons with tooltip.
- Guard JSON parsing with try/catch.

---

## 9) Performance
- Load vendor scripts at end; reuse chart instances; batch DOM updates; keep page weight low (< 250KB where possible).

---

## 10) Security/Privacy
- No backend; history only in localStorage.
- HTTPS via GitHub Pages; consider SRI for CDN in future.

---

## 11) Testing Checklist
- **Formulas**: known samples (e.g., 2000 @ 15%/5%) → View‑3 Net≈1652; View‑5 Net≈1900.
- **UX**: BN/EN toggle; theme toggle; category width fixed; keyboard tab order.
- **Resilience**: Choices off; `rates.json` missing; long content PDF pagination.

---

## 12) Deploy (GitHub Pages)
1) Put files at repo root; ensure `data/rates.json` exists.
2) Settings → Pages → Deploy from a branch → **main** (root).
3) Wait 1–2 minutes; **Hard refresh** (Ctrl+F5 / Cmd+Shift+R).

---

## 13) Versioning & Release
- **SemVer**: MAJOR.MINOR.PATCH  
- **CHANGELOG.md** must be updated per release (Added/Changed/Fixed/Removed).
- Release checklist: rates schema intact, i18n coverage, light/dark & mobile tests, charts/report validated, Pages cache note.

---

## 14) Contribution Guidelines (PRs)
- Branch strategy: `main` (live), `dev`, feature branches (e.g., `feat/report` / `fix/choices`).
- Every PR must include: summary, screenshots (light/dark), test notes, i18n keys, checklist.
- Code style: readable vanilla JS; consider Prettier/ESLint if team grows.

---

## 15) Backlog (optional)
- Preset manager (named presets), CSV/XLSX export (all 5 views), PWA, brand theming.
